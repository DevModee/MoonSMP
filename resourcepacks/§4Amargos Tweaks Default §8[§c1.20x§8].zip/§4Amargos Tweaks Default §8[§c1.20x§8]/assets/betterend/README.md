[![](https://jitpack.io/v/quiqueck/BetterEnd.svg)](https://jitpack.io/#quiqueck/BetterEnd)

# Better End

Better End Mod for Fabric, MC 1.19

Importing:

* Clone repo
* Edit gradle.properties if necessary
* Run command line in folder: gradlew genSources idea (or eclipse)
* Import project to IDE

Building:

* Clone repo
* Run command line in folder: gradlew build
* Mod .jar will be in ./build/libs

